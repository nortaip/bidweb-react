import { memo } from 'react';
import type { FC, ReactNode } from 'react';

import resets from '../../_resets.module.css';
import classes from './IcActionsStar.module.css';
import { LayerIcon } from './LayerIcon';

interface Props {
  className?: string;
  classes?: {
    layer?: string;
    root?: string;
  };
  swap?: {
    layer?: ReactNode;
  };
}
/* @figmaId 27:5713 */
export const IcActionsStar: FC<Props> = memo(function IcActionsStar(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${props.classes?.root || ''} ${props.className || ''} ${classes.root}`}>
      <div className={`${props.classes?.layer || ''} ${classes.layer}`}>
        {props.swap?.layer || <LayerIcon className={classes.icon} />}
      </div>
    </div>
  );
});
