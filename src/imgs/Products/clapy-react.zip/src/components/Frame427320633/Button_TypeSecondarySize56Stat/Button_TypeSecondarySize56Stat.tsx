import { memo } from 'react';
import type { FC, ReactNode } from 'react';

import resets from '../../_resets.module.css';
import { MasterButton_IconPositionOffSi2 } from '../MasterButton_IconPositionOffSi2/MasterButton_IconPositionOffSi2';
import classes from './Button_TypeSecondarySize56Stat.module.css';

interface Props {
  className?: string;
  text?: {
    label?: ReactNode;
  };
}
/* @figmaId 8:7097 */
export const Button_TypeSecondarySize56Stat: FC<Props> = memo(function Button_TypeSecondarySize56Stat(props = {}) {
  return (
    <button className={`${resets.clapyResets} ${classes.root}`}>
      <MasterButton_IconPositionOffSi2
        className={classes.iconOffSize56}
        text={{
          label: props.text?.label || <div className={classes.label}>Label</div>,
        }}
      />
    </button>
  );
});
