import { memo } from 'react';
import type { FC, ReactNode } from 'react';

import resets from '../../_resets.module.css';
import { Ellipse463Icon } from './Ellipse463Icon';
import classes from './Frame427320631.module.css';

interface Props {
  className?: string;
  swap?: {
    ellipse463?: ReactNode;
  };
  text?: {
    status?: ReactNode;
  };
}
/* @figmaId 102:6556 */
export const Frame427320631: FC<Props> = memo(function Frame427320631(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.ellipse463}>{props.swap?.ellipse463 || <Ellipse463Icon className={classes.icon} />}</div>
      {props.text?.status != null ? props.text?.status : <div className={classes.status}>Status</div>}
    </div>
  );
});
