import { memo } from 'react';
import type { FC, ReactNode } from 'react';

import resets from '../../_resets.module.css';
import { MasterInputPlaceholder_Content } from '../MasterInputPlaceholder_Content/MasterInputPlaceholder_Content';
import classes from './MasterInputSize_Size56.module.css';

interface Props {
  className?: string;
  classes?: {
    contentTextRightIcon?: string;
    autoLayoutHorizontal?: string;
    root?: string;
  };
  swap?: {
    group?: ReactNode;
  };
  hide?: {
    icon16View?: boolean;
    autoLayoutHorizontal?: boolean;
  };
  text?: {
    label?: ReactNode;
    placeholder?: ReactNode;
    helperText?: ReactNode;
  };
}
/* @figmaId 8:7665 */
export const MasterInputSize_Size56: FC<Props> = memo(function MasterInputSize_Size56(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${props.classes?.root || ''} ${props.className || ''} ${classes.root}`}>
      <div className={classes.autoLayoutHorizontal2}>
        {props.text?.label != null ? props.text?.label : <div className={classes.label}>Label</div>}
      </div>
      <div className={`${props.classes?.autoLayoutHorizontal || ''} ${classes.autoLayoutHorizontal}`}>
        <MasterInputPlaceholder_Content
          className={`${props.classes?.contentTextRightIcon || ''} ${classes.contentTextRightIcon}`}
          swap={{
            group: props.swap?.group,
          }}
          hide={{
            icon16View: props.hide?.icon16View,
          }}
          text={{
            placeholder: props.text?.placeholder || <div className={classes.placeholder}>Placeholder</div>,
          }}
        />
      </div>
      {!props.hide?.autoLayoutHorizontal && (
        <div className={classes.autoLayoutHorizontal3}>
          {props.text?.helperText != null ? (
            props.text?.helperText
          ) : (
            <div className={classes.helperText}>Helper Text</div>
          )}
        </div>
      )}
    </div>
  );
});
