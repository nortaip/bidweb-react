import { memo } from 'react';
import type { FC, ReactNode } from 'react';

import resets from '../../_resets.module.css';
import { Icon16View } from '../Icon16View/Icon16View';
import classes from './MasterInputPlaceholder_Content.module.css';

interface Props {
  className?: string;
  classes?: {
    root?: string;
  };
  swap?: {
    group?: ReactNode;
  };
  hide?: {
    icon16View?: boolean;
  };
  text?: {
    placeholder?: ReactNode;
  };
}
/* @figmaId 8:7642 */
export const MasterInputPlaceholder_Content: FC<Props> = memo(function MasterInputPlaceholder_Content(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${props.classes?.root || ''} ${props.className || ''} ${classes.root}`}>
      {props.text?.placeholder != null ? (
        props.text?.placeholder
      ) : (
        <div className={classes.placeholder}>Placeholder</div>
      )}
      {!props.hide?.icon16View && (
        <Icon16View
          swap={{
            group: props.swap?.group,
          }}
        />
      )}
    </div>
  );
});
