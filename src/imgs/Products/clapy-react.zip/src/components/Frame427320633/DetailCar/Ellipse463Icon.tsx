import { memo, SVGProps } from 'react';

const Ellipse463Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 5 6' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <circle cx={2.5} cy={3} r={2.5} fill='#B2D182' />
  </svg>
);

const Memo = memo(Ellipse463Icon);
export { Memo as Ellipse463Icon };
