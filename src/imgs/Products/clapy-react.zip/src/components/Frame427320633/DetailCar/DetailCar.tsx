import { memo } from 'react';
import type { FC } from 'react';

import resets from '../../_resets.module.css';
import { Button_TypePrimarySize32StateF } from '../Button_TypePrimarySize32StateF/Button_TypePrimarySize32StateF';
import { Button_TypePrimarySize56StateD } from '../Button_TypePrimarySize56StateD/Button_TypePrimarySize56StateD';
import { Button_TypeSecondarySize56Stat } from '../Button_TypeSecondarySize56Stat/Button_TypeSecondarySize56Stat';
import { Frame427320631 } from '../Frame427320631/Frame427320631';
import { Frame427320632_Property1Defaul } from '../Frame427320632_Property1Defaul/Frame427320632_Property1Defaul';
import { Input_StateDefaultSize56 } from '../Input_StateDefaultSize56/Input_StateDefaultSize56';
import classes from './DetailCar.module.css';
import { Ellipse463Icon } from './Ellipse463Icon';

interface Props {
  className?: string;
  hide?: {
    icon16View?: boolean;
    icon16View2?: boolean;
    autoLayoutHorizontal?: boolean;
  };
}
/* @figmaId 237:6822 */
export const DetailCar: FC<Props> = memo(function DetailCar(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.frame427320631}>
        <div className={classes.frame4273206312}>
          <div className={classes.frame4273206313}>
            <div className={classes.lotNumber}>Lot number</div>
            <div className={classes.frame4273206314}>
              <div className={classes._250355}>250355</div>
            </div>
          </div>
          <div className={classes.frame4273206315}>
            <div className={classes.auction}>Auction</div>
            <div className={classes.maxsim}>Maxsim</div>
          </div>
          <div className={classes.frame427320634}>
            <div className={classes.dateTime}>Date/time</div>
            <div className={classes._1692021948}>16.09.2021 09:48</div>
          </div>
          <div className={classes.frame427320635}>
            <div className={classes.status2}>Status</div>
            <Frame427320631
              swap={{
                ellipse463: <Ellipse463Icon className={classes.icon} />,
              }}
              text={{
                status: <div className={classes.status}>Online</div>,
              }}
            />
          </div>
        </div>
        <div className={classes.frame427320636}>
          <div className={classes.condition}>Condition</div>
          <div className={classes._45}>4.5</div>
        </div>
      </div>
      <div className={classes.frame4273206316}>
        <div className={classes.frame427320643}>
          <div className={classes.frame4273206317}>
            <div className={classes.marka}>Marka</div>
          </div>
          <div className={classes.frame4273206318}>
            <div className={classes.nissan}>Nissan</div>
          </div>
          <div className={classes.frame4273206319}>
            <div className={classes.muhRrikGucu}>Mühərrik gücü</div>
          </div>
          <div className={classes.frame427320633}>
            <div className={classes.group427320632}>
              <div className={classes._450AG}>450 a.g</div>
            </div>
          </div>
        </div>
        <div className={classes.frame427320642}>
          <div className={classes.frame42732063110}>
            <div className={classes.model}>Model</div>
          </div>
          <div className={classes.frame4273206332}>
            <div className={classes.gtr}>Gtr</div>
          </div>
          <div className={classes.frame42732063111}>
            <div className={classes.muhRrik}>Mühərrik</div>
          </div>
          <div className={classes.frame4273206333}>
            <div className={classes._3L}>3.0L</div>
          </div>
        </div>
        <div className={classes.frame427320644}>
          <div className={classes.frame42732063112}>
            <div className={classes.buraxLSIli}>Buraxılış ili</div>
          </div>
          <div className={classes.frame4273206334}>
            <div className={classes._2010}>2010</div>
          </div>
          <div className={classes.frame42732063113}>
            <div className={classes.yanacaqNovu}>Yanacaq növü</div>
          </div>
          <div className={classes.frame4273206335}>
            <div className={classes.benzin}>Benzin</div>
          </div>
        </div>
        <div className={classes.frame427320645}>
          <div className={classes.frame42732063114}>
            <div className={classes.banNovu}>Ban növü</div>
          </div>
          <div className={classes.frame4273206336}>
            <div className={classes.kupe}>Kupe</div>
          </div>
          <div className={classes.frame42732063115}>
            <div className={classes.yurus}>Yürüş</div>
          </div>
          <div className={classes.frame4273206337}>
            <div className={classes._3700Km}>3 700 km</div>
          </div>
        </div>
        <div className={classes.frame427320646}>
          <div className={classes.frame42732063116}>
            <div className={classes.sassiID}>Şassi İD</div>
          </div>
          <div className={classes.frame4273206338}>
            <div className={classes.nZ6}>NZ6</div>
          </div>
          <div className={classes.frame42732063117}>
            <div className={classes.surTlRQutusu}>Sürətlər qutusu</div>
          </div>
          <div className={classes.frame4273206339}>
            <div className={classes.avtomat}>Avtomat</div>
          </div>
        </div>
        <div className={classes.frame427320647}>
          <div className={classes.frame42732063118}>
            <div className={classes.rNg}>Rəng</div>
          </div>
          <div className={classes.frame42732063310}>
            <div className={classes.qara}>Qara</div>
          </div>
          <div className={classes.frame42732063119}>
            <div className={classes.oturucu}>Ötürücü</div>
          </div>
          <div className={classes.frame42732063311}>
            <div className={classes.tam}>Tam</div>
          </div>
        </div>
      </div>
      <div className={classes.frame427320630}>
        <div className={classes.price}>
          <div className={classes.frame42732063120}>
            <div className={classes._1800}>$180.00/ </div>
            <div className={classes.currentBid}>current bid</div>
          </div>
          <div className={classes.frame42732063121}>
            <div className={classes._1000}>$100.00</div>
            <div className={classes.startPrice}>start price</div>
          </div>
        </div>
        <Button_TypePrimarySize32StateF
          classes={{ iconOffSize32: classes.iconOffSize32 }}
          text={{
            label: <div className={classes.label}>you are winnig!</div>,
          }}
        />
      </div>
      <div className={classes.frame42732063122}>
        <div className={classes.countdown}>
          <div className={classes._255}>2:55</div>
          <div className={classes.countdown2}>Countdown</div>
          <Frame427320632_Property1Defaul />
        </div>
        <div className={classes.frame42732063312}>
          <Input_StateDefaultSize56
            className={classes.input}
            classes={{ contentTextRightIcon: classes.contentTextRightIcon }}
            hide={{
              icon16View: true,
            }}
            text={{
              label: <div className={classes.label2}>your bid</div>,
              placeholder: <div className={classes.placeholder}>$ 190.00</div>,
              helperText: <div className={classes.helperText}>min bid +10 $</div>,
            }}
          />
          <div className={classes.butons}>
            <Button_TypeSecondarySize56Stat
              text={{
                label: <div className={classes.label3}>Auto</div>,
              }}
            />
            <Button_TypePrimarySize56StateD
              text={{
                label: <div className={classes.label4}>Bid Your Price</div>,
              }}
            />
          </div>
        </div>
        <div className={classes.frame4273206342}>
          <Input_StateDefaultSize56
            className={classes.input2}
            classes={{
              contentTextRightIcon: classes.contentTextRightIcon2,
              autoLayoutHorizontal: classes.autoLayoutHorizontal,
              size56: classes.size56,
            }}
            hide={{
              icon16View: true,
              autoLayoutHorizontal: true,
            }}
            text={{
              label: <div className={classes.label5}>Buy now price</div>,
              placeholder: <div className={classes.placeholder2}>$ 190.00</div>,
            }}
          />
          <div className={classes.butons2}>
            <Button_TypeSecondarySize56Stat
              text={{
                label: <div className={classes.label6}>Buy now</div>,
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
});
