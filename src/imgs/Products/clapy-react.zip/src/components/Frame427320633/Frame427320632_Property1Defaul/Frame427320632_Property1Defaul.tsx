import { memo } from 'react';
import type { FC } from 'react';

import resets from '../../_resets.module.css';
import classes from './Frame427320632_Property1Defaul.module.css';

interface Props {
  className?: string;
}
/* @figmaId 33:6273 */
export const Frame427320632_Property1Defaul: FC<Props> = memo(function Frame427320632_Property1Defaul(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.rectangle23792}></div>
      <div className={classes.rectangle23793}></div>
      <div className={classes.rectangle23794}></div>
    </div>
  );
});
