import { memo } from 'react';
import type { FC } from 'react';

import resets from '../../_resets.module.css';
import { FrameIcon } from './FrameIcon';
import { FrameIcon2 } from './FrameIcon2';
import { FrameIcon3 } from './FrameIcon3';
import { FrameIcon4 } from './FrameIcon4';
import classes from './Reviews.module.css';

interface Props {
  className?: string;
}
/* @figmaId 237:6833 */
export const Reviews: FC<Props> = memo(function Reviews(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.totalReview}>
        <div className={classes.liveChat}>Live chat</div>
        <div className={classes.totalReview2}>
          <div className={classes._13}>13</div>
        </div>
      </div>
      <div className={classes.chat}>
        <div className={classes.div}>
          <div className={classes.div2}>
            <div className={classes._2145}>21:45</div>
            <div className={classes.div3}>
              <div className={classes.span}>
                <div className={classes._1}></div>
                <div className={classes._12}></div>
              </div>
              <div className={classes.nortaip}>nortaip</div>
            </div>
          </div>
          <div className={classes.SohbetciHesapDogrulamaAyarlarN}>
            : Sohbetçi hesap doğrulama ayarları nortaip güncelledi: Bazı kişilerin sohbete katılması için telefon
            doğrulaması gerekir: Yeni Sohbetçiler, Hesabın yaşı en az 1 hafta olmalı. Tüm kişilerin sohbete katılması
            için e-posta doğrulaması gerekir. Muaf: Moderatörler • 34 dakika önceSohbetçi hesap doğrulama ayarları
            nortaip güncelledi: Bazı kişilerin sohbete katılması için telefon doğrulaması gerekir: Yeni Sohbetçiler,
            Hesabın yaşı en az 1 hafta olmalı. Tüm kişilerin sohbete katılması için e-posta
          </div>
        </div>
        <div className={classes.div4}>
          <div className={classes.div5}>
            <div className={classes._21452}>21:45</div>
            <div className={classes.div6}>
              <div className={classes.span2}>
                <div className={classes._14}></div>
                <div className={classes._15}></div>
              </div>
              <div className={classes.nortaip2}>nortaip</div>
            </div>
          </div>
          <div className={classes.SohbetciHesapDogrulamaAyarlarN2}>
            : Sohbetçi hesap doğrulama ayarları nortaip güncelledi: Bazı kişilerin sohbete katılması için telefon
            doğrulaması gerekir: Yeni Sohbetçiler, Hesabın yaşı en az 1 hafta olmalı. Tüm kişilerin sohbete katılması
            için e-posta doğrulaması gerekir. Muaf: Moderatörler • 34 dakika önceSohbetçi hesap doğrulama ayarları
            nortaip güncelledi: Bazı kişilerin sohbete katılması için telefon doğrulaması gerekir: Yeni Sohbetçiler,
            Hesabın yaşı en az 1 hafta olmalı. Tüm kişilerin sohbete katılması için e-posta
          </div>
        </div>
        <div className={classes.div7}>
          <div className={classes.div8}>
            <div className={classes._21453}>21:45</div>
            <div className={classes.div9}>
              <div className={classes.span3}>
                <div className={classes._16}></div>
                <div className={classes._17}></div>
              </div>
              <div className={classes.nortaip3}>nortaip</div>
            </div>
          </div>
          <div className={classes.Ssfdgsdfhgjshdfkgjhnadkjvgasdf}>: Ssfdgsdfhgjshdfkgjhnadkjvgasdfgdf</div>
        </div>
        <div className={classes.div10}>
          <div className={classes.div11}>
            <div className={classes._21454}>21:45</div>
            <div className={classes.div12}>
              <div className={classes.span4}>
                <div className={classes._18}></div>
                <div className={classes._19}></div>
              </div>
              <div className={classes.nortaip4}>nortaip</div>
            </div>
          </div>
          <div className={classes.Ssfdgsdfhgjshdfkgjhnadkjvgasdf2}>: Ssfdgsdfhgjshdfkgjhnadkjvgasdfgdf</div>
        </div>
        <div className={classes.div13}>
          <div className={classes.div14}>
            <div className={classes._21455}>21:45</div>
            <div className={classes.div15}>
              <div className={classes.span5}>
                <div className={classes._110}></div>
                <div className={classes._111}></div>
              </div>
              <div className={classes.nortaip5}>nortaip</div>
            </div>
          </div>
          <div className={classes.Ssfdgsdfhgjshdfkgjhnadkjvgasdf3}>: Ssfdgsdfhgjshdfkgjhnadkjvgasdfgdf</div>
        </div>
        <div className={classes.div16}>
          <div className={classes.div17}>
            <div className={classes._21456}>21:45</div>
            <div className={classes.div18}>
              <div className={classes.span6}>
                <div className={classes._112}></div>
                <div className={classes._113}></div>
              </div>
              <div className={classes.nortaip6}>nortaip</div>
            </div>
          </div>
          <div className={classes.Ssfdgsdfhgjshdfkgjhnadkjvgasdf4}>: Ssfdgsdfhgjshdfkgjhnadkjvgasdfgdf</div>
        </div>
        <div className={classes.div19}>
          <div className={classes.div20}>
            <div className={classes._21457}>21:45</div>
            <div className={classes.div21}>
              <div className={classes.span7}>
                <div className={classes._114}></div>
                <div className={classes._115}></div>
              </div>
              <div className={classes.nortaip7}>nortaip</div>
            </div>
          </div>
          <div className={classes.Ssfdgsdfhgjshdfkgjhnadkjvgasdf5}>: Ssfdgsdfhgjshdfkgjhnadkjvgasdfgdf</div>
        </div>
        <div className={classes.nortaipBuOdaIcinSadeceTakipcil}>
          nortaip bu oda için sadece takipçiler modunu devre dışı bıraktı.
        </div>
      </div>
      <div className={classes.boxInput}>
        <div className={classes.div22}>
          <div className={classes.div23}>
            <div className={classes.div24}>
              <div className={classes.birMesajGonderin}>Bir mesaj gönderin</div>
            </div>
            <div className={classes.ifadeSecici}>
              <div className={classes.div25}>
                <div className={classes.svg}>
                  <div className={classes.frame}>
                    <FrameIcon3 className={classes.icon} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={classes.div26}>
          <div className={classes.div27}>
            <div className={classes.frame427320633}>
              <div className={classes.kalkanModuAcKKalkanModunuYonet}>
                <div className={classes.div28}>
                  <div className={classes.svg2}>
                    <div className={classes.frame2}>
                      <FrameIcon4 className={classes.icon2} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <button className={classes.button}>
              <div className={classes.sohbet}>Sohbet</div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
});
