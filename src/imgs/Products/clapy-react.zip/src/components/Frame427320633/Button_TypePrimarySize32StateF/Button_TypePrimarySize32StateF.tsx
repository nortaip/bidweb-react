import { memo } from 'react';
import type { FC, ReactNode } from 'react';

import resets from '../../_resets.module.css';
import { MasterButton_IconPositionOffSi } from '../MasterButton_IconPositionOffSi/MasterButton_IconPositionOffSi';
import classes from './Button_TypePrimarySize32StateF.module.css';

interface Props {
  className?: string;
  classes?: {
    iconOffSize32?: string;
  };
  text?: {
    label?: ReactNode;
  };
}
/* @figmaId 8:7387 */
export const Button_TypePrimarySize32StateF: FC<Props> = memo(function Button_TypePrimarySize32StateF(props = {}) {
  return (
    <button className={`${resets.clapyResets} ${classes.root}`}>
      <MasterButton_IconPositionOffSi
        className={`${props.classes?.iconOffSize32 || ''} ${classes.iconOffSize32}`}
        text={{
          label: props.text?.label,
        }}
      />
    </button>
  );
});
