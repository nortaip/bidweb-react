import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { DetailCar } from './DetailCar/DetailCar';
import { Frame427320630 } from './Frame427320630/Frame427320630';
import classes from './Frame427320633.module.css';
import { Reviews } from './Reviews/Reviews';

interface Props {
  className?: string;
}
/* @figmaId 224:6888 */
export const Frame427320633: FC<Props> = memo(function Frame427320633(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.frame427320633}>
        <div className={classes.frame4273206332}>
          <Frame427320630 />
          <DetailCar />
        </div>
        <div className={classes.description}>
          <div className={classes.totalReview}>
            <div className={classes.description2}>Description</div>
          </div>
          <div className={classes.frame4273206333}>
            <div className={classes.nISMOHasBecomeTheEmbodimentOfN}>
              NISMO has become the embodiment of Nissan&#39;s outstanding performance, inspired by the most unforgiving
              proving ground, the &quot;race track&quot;.
            </div>
          </div>
        </div>
      </div>
      <Reviews />
    </div>
  );
});
