import { memo } from 'react';
import type { FC, ReactNode } from 'react';

import resets from '../../_resets.module.css';
import { MasterButton_IconPositionOffSi2 } from '../MasterButton_IconPositionOffSi2/MasterButton_IconPositionOffSi2';
import classes from './Button_TypePrimarySize56StateD.module.css';

interface Props {
  className?: string;
  text?: {
    label?: ReactNode;
  };
}
/* @figmaId 8:6975 */
export const Button_TypePrimarySize56StateD: FC<Props> = memo(function Button_TypePrimarySize56StateD(props = {}) {
  return (
    <button className={`${resets.clapyResets} ${classes.root}`}>
      <MasterButton_IconPositionOffSi2
        text={{
          label: props.text?.label,
        }}
      />
    </button>
  );
});
