import { memo, SVGProps } from 'react';

const Frame427320631Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 28 6' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <circle cx={3} cy={3} r={3} fill='#DDDDDD' />
    <rect x={8} width={12} height={6} rx={3} fill='#6042E9' />
    <circle cx={25} cy={3} r={3} fill='#DDDDDD' />
  </svg>
);

const Memo = memo(Frame427320631Icon);
export { Memo as Frame427320631Icon };
