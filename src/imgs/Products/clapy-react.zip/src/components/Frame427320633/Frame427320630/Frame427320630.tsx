import { memo } from 'react';
import type { FC } from 'react';

import resets from '../../_resets.module.css';
import { ArrowsLeftArrow } from '../ArrowsLeftArrow/ArrowsLeftArrow';
import { Heart_ThemeOutline } from '../Heart_ThemeOutline/Heart_ThemeOutline';
import { IcActionsStar } from '../IcActionsStar/IcActionsStar';
import classes from './Frame427320630.module.css';
import { Frame427320631Icon } from './Frame427320631Icon';
import { LayerIcon } from './LayerIcon';
import { LayerIcon2 } from './LayerIcon2';
import { LayerIcon3 } from './LayerIcon3';
import { LayerIcon4 } from './LayerIcon4';
import { LayerIcon5 } from './LayerIcon5';

interface Props {
  className?: string;
}
/* @figmaId 237:6821 */
export const Frame427320630: FC<Props> = memo(function Frame427320630(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.frame427320633}>
        <ArrowsLeftArrow />
        <div className={classes.frame427320629}>
          <div className={classes.carName}>
            <div className={classes.nissanGTR}>Nissan GT - R</div>
            <div className={classes.reviews}>
              <div className={classes.reviewStar}>
                <IcActionsStar
                  className={classes.icActionsStar}
                  classes={{ layer: classes.layer }}
                  swap={{
                    layer: (
                      <div className={classes.layer}>
                        <LayerIcon className={classes.icon} />
                      </div>
                    ),
                  }}
                />
                <IcActionsStar
                  className={classes.icActionsStar2}
                  classes={{ layer: classes.layer2 }}
                  swap={{
                    layer: (
                      <div className={classes.layer2}>
                        <LayerIcon2 className={classes.icon2} />
                      </div>
                    ),
                  }}
                />
                <IcActionsStar
                  className={classes.icActionsStar3}
                  classes={{ layer: classes.layer3 }}
                  swap={{
                    layer: (
                      <div className={classes.layer3}>
                        <LayerIcon3 className={classes.icon3} />
                      </div>
                    ),
                  }}
                />
                <IcActionsStar
                  className={classes.icActionsStar4}
                  classes={{ layer: classes.layer4 }}
                  swap={{
                    layer: (
                      <div className={classes.layer4}>
                        <LayerIcon4 className={classes.icon4} />
                      </div>
                    ),
                  }}
                />
                <IcActionsStar
                  className={classes.icActionsStar5}
                  classes={{ layer: classes.layer5 }}
                  swap={{
                    layer: (
                      <div className={classes.layer5}>
                        <LayerIcon5 className={classes.icon5} />
                      </div>
                    ),
                  }}
                />
              </div>
              <div className={classes._440Reviewer}>440+ Reviewer</div>
            </div>
          </div>
          <div className={classes.frame427320631}>
            <div className={classes.frame4273206312}>
              <div className={classes.lIVE}>LIVE</div>
            </div>
            <Heart_ThemeOutline />
          </div>
        </div>
      </div>
      <div className={classes.frame427320632}>
        <div className={classes.view}>
          <div className={classes.view2}></div>
          <div className={classes.frame4273206313}>
            <Frame427320631Icon className={classes.icon6} />
          </div>
        </div>
        <div className={classes.frame4273206332}>
          <div className={classes.view22}></div>
          <div className={classes.view3}></div>
          <div className={classes.view23}></div>
        </div>
        <div className={classes.frame427320634}>
          <div className={classes.view24}></div>
          <div className={classes.view32}></div>
          <div className={classes.view25}></div>
        </div>
      </div>
    </div>
  );
});
