import { memo } from 'react';
import type { FC, ReactNode } from 'react';

import resets from '../../_resets.module.css';
import { MasterInputSize_Size56 } from '../MasterInputSize_Size56/MasterInputSize_Size56';
import { GroupIcon } from './GroupIcon';
import classes from './Input_StateDefaultSize56.module.css';

interface Props {
  className?: string;
  classes?: {
    contentTextRightIcon?: string;
    root?: string;
    autoLayoutHorizontal?: string;
    size56?: string;
  };
  hide?: {
    icon16View?: boolean;
    autoLayoutHorizontal?: boolean;
  };
  text?: {
    label?: ReactNode;
    placeholder?: ReactNode;
    helperText?: ReactNode;
  };
}
/* @figmaId 8:7601 */
export const Input_StateDefaultSize56: FC<Props> = memo(function Input_StateDefaultSize56(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${props.classes?.root || ''} ${props.className || ''} ${classes.root}`}>
      <MasterInputSize_Size56
        className={`${props.classes?.size56 || ''} ${classes.size56}`}
        classes={{
          contentTextRightIcon: `${props.classes?.contentTextRightIcon || ''} ${classes.contentTextRightIcon}`,
          autoLayoutHorizontal: `${props.classes?.autoLayoutHorizontal || ''} ${classes.autoLayoutHorizontal}`,
        }}
        swap={{
          group: <GroupIcon className={classes.icon} />,
        }}
        hide={{
          icon16View: props.hide?.icon16View,
          autoLayoutHorizontal: props.hide?.autoLayoutHorizontal,
        }}
        text={{
          label: props.text?.label || <div className={classes.label}>Label</div>,
          placeholder: props.text?.placeholder || <div className={classes.placeholder}>Placeholder</div>,
          helperText: props.text?.helperText || <div className={classes.helperText}>Helper Text</div>,
        }}
      />
    </div>
  );
});
